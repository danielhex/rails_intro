# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rottenpotatoes::Application.config.secret_token = 'da54a3c382cd9140768e980bd512fc0344be23a8f5831a47f18f2e7bd89231abda87ed4e51812946cd0e847167dc145236467c6c59670a9a114059ada1955e38'
